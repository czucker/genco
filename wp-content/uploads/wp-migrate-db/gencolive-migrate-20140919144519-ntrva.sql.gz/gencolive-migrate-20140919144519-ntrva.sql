# WordPress MySQL database migration
#
# Generated: Friday 19. September 2014 14:45 UTC
# Hostname: localhost
# Database: `gencoLive`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';

